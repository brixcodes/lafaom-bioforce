import { Component } from '@angular/core';

@Component({
  selector: 'app-sessions',
  standalone: true,
  imports: [],
  templateUrl: './sessions.html',
  styleUrl: './sessions.css'
})
export class Sessions {

}
