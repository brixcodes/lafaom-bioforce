import { Component } from '@angular/core';

@Component({
  selector: 'app-section-2',
  standalone: true,
  imports: [],
  templateUrl: './section-2.html',
  styleUrl: './section-2.css'
})
export class Section2 {

}
