import { Component } from '@angular/core';

@Component({
  selector: 'app-language',
  imports: [],
  templateUrl: './language.html',
  styleUrl: './language.css'
})
export class Language {

}
